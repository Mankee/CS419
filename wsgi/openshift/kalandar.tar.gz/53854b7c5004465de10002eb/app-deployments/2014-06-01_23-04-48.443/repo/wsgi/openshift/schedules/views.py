from distutils.command.build import build
import logging
import os
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.http import HttpResponseRedirect, HttpResponseForbidden, HttpResponseBadRequest
from django.shortcuts import render_to_response, render
from django.template import RequestContext
import httplib2
from oauth2client import xsrfutil
from oauth2client.client import flow_from_clientsecrets
from oauth2client.django_orm import Storage
from django_cas.views import _redirect_url, _service_url, _login_url
from django.template import Context, Template
from schedules.models import Event, CredentialsModel
# Create your views here.
import settings


def index(request):
    # Obtain the context from the HTTP request.
    context = RequestContext(request)

    # Query the database for a list of ALL events stored per Calendar.
    all_events = Event.objects.all()
    context_dict = {'Events': all_events}

    # Render the response and send it back!
    return render_to_response('schedules/index.html', context_dict, context)


def render_schedule(request, next_page=None, required=True):
    if request.user.is_authenticated():
        # Query the database for a list of ALL events stored per Calendar.
        all_events = Event.objects.all()
        data = {'Events': all_events}
        return render_to_response('schedules/main.html', data)
    else:
        logging.error(
            'redirecting to login from render_schedule... could not authenticate user ' + request.user.username)
        service = _service_url(request, next_page)
        return HttpResponseRedirect(_login_url(service))


# CLIENT_SECRETS, name of a file containing the OAuth 2.0 information for this
# application, including client_id and client_secret, which are found
# on the API Access tab on the Google APIs
# Console <http://code.google.com/apis/console>
CLIENT_SECRETS = os.path.join(os.path.dirname(__file__), 'client_secrets.json')

FLOW = flow_from_clientsecrets(
    CLIENT_SECRETS,
    scope='https://www.google.com/m8/feeds',
    redirect_uri='https://kalandar-oregonstate.rhcloud.com/oauth2callback')


def oauth2(request):
    storage = Storage(CredentialsModel, 'id', request.user.id, 'credential')
    credential = storage.get()
    if credential is None or credential.invalid == True:
        FLOW.params['state'] = xsrfutil.generate_token(settings.SECRET_KEY,
                                                       request.user.id)
        authorize_url = FLOW.step1_get_authorize_url()
        return HttpResponseRedirect(authorize_url)
    else:
        http = httplib2.Http()
        http = credential.authorize(http)
        service = build("kalandar", "v1", http=http)
        activities = service.activities()
        activitylist = activities.list(collection='public',
                                       userId='me').execute()
        logging.info(activitylist)

        return render_to_response('plus/welcome.html', {
            'activitylist': activitylist,
        })


def auth_return(request):
    if not xsrfutil.validate_token(settings.SECRET_KEY, request.REQUEST['state'],
                                   request.user.id):
        logging.error('could not authenticate with Oauth2' + request.user.id)
        return HttpResponseBadRequest()
    credential = FLOW.step2_exchange(request.REQUEST)
    storage = Storage(CredentialsModel, 'id', request.user.id, 'credential')
    storage.put(credential)
    return HttpResponseRedirect("/")