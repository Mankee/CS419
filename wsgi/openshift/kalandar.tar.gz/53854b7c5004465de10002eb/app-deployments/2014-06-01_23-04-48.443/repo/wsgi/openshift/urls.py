from django.conf.urls import patterns, include, url

from django.contrib import admin
from schedules import views

admin.autodiscover()

urlpatterns = patterns('',
    # Examples:
    url(r'^$', 'schedules.views.index'),
    url(r'^schedule/', include('schedules.urls')),
    url(r'^admin/', include(admin.site.urls)),
    url(r'^oauth2/', 'schedules.views.oauth2'),
    url(r'^oauth2callback', 'schedules.views.auth_return'),

    # CAS URLS for logging users in and out of the web application (temporarly disabled)
    url(r'^login/$', 'django_cas.views.login'),
    url(r'^logout/$', 'django_cas.views.logout'),

)
